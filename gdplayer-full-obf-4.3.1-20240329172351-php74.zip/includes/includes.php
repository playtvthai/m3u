<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:37              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto KU8HdbK2F9hL8YG2; csKx1I9jMKHw7htr: include_once __DIR__ . "\x2f\143\x6f\156\146\x69\x67\x2e\x70\150\x70"; goto Gjt8mMWeoFxIznQX; Gjt8mMWeoFxIznQX: include_once __DIR__ . "\57\146\165\x6e\x63\x74\151\x6f\156\163\x2e\160\x68\x70"; goto mxhLabd4KdaLuKFx; KU8HdbK2F9hL8YG2: session_write_close(); goto d0eDKkJ6Q4KYyXIK; d0eDKkJ6Q4KYyXIK: include_once __DIR__ . "\57\x2e\x2e\x2f\166\x65\156\144\x6f\x72\57\141\x75\164\x6f\154\157\141\x64\x2e\160\x68\160"; goto csKx1I9jMKHw7htr; mxhLabd4KdaLuKFx: include_once __DIR__ . "\57\x70\x6c\165\x67\151\156\163\56\160\x68\x70";
