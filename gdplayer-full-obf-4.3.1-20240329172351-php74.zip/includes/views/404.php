<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:37              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto hVE3R_lBwMatv0sg; HQ4ul9bcWdAzskLF: echo "\74\144\x69\x76\x20\143\154\141\x73\x73\75\42\x72\x6f\167\x20\160\x74\55\x35\42\x3e\xa\40\40\40\x20\x3c\x64\151\x76\40\143\x6c\141\x73\163\75\x22\x63\x6f\x6c\55\61\x32\40\x74\x65\x78\164\55\x63\145\156\x74\x65\162\42\76\xa\40\40\x20\x20\40\40\x20\40\74\x68\61\x20\143\x6c\141\163\x73\x3d\x22\x68\x33\x20\164\145\x78\164\x2d\144\x61\x6e\147\x65\x72\x22\x3e"; goto GsPyv0nIlfWgfH5D; hVE3R_lBwMatv0sg: session_write_close(); goto ozKjL1TYXW65UlXZ; sw0PiFMNidds2EVO: get_frontend_header(); goto HQ4ul9bcWdAzskLF; GsPyv0nIlfWgfH5D: echo get_env("\x74\x69\164\x6c\145"); goto vuDP_emHLtrVV2G0; ozKjL1TYXW65UlXZ: set_env("\164\x69\164\154\x65", "\64\60\64\x20\x50\x61\147\145\x20\x4e\x6f\164\x20\x46\157\165\156\x64"); goto sw0PiFMNidds2EVO; vuDP_emHLtrVV2G0: echo "\x3c\57\150\x31\x3e\12\40\x20\40\x20\x20\40\40\40\x3c\x68\63\x20\143\x6c\x61\163\x73\x3d\x22\150\64\x20\164\x65\x78\164\55\x73\145\143\x6f\156\x64\x61\x72\171\42\76\124\x68\145\40\160\141\147\145\40\x79\x6f\x75\x20\x61\162\x65\40\x6c\157\157\153\x69\x6e\x67\x20\x66\x6f\162\x20\x77\x61\x73\x20\x6e\x6f\164\x20\x66\x6f\165\156\144\x2e\74\57\x68\x33\76\xa\x20\40\40\x20\74\57\x64\x69\166\76\12\74\x2f\x64\x69\x76\76\xa"; goto RKXpizx8BItzCr_B; RKXpizx8BItzCr_B: get_frontend_footer();
