<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto LFi5N7gy7iB5ZUfp; LFi5N7gy7iB5ZUfp: session_write_close(); goto q3855SxiAehGuZs1; pm3EARXPPHodD9II: $html = new \GDPlayer\HTML(); goto ak9hvIpGt1CiE__s; q3855SxiAehGuZs1: include_once BASE_DIR . "\x69\156\143\154\165\x64\145\163\x2f\151\x73\101\144\155\x69\156\x2e\x70\150\x70"; goto GbCACEgQiJJSYbha; Z5NaaG30sCWtNQmv: get_backend_header(); goto pm3EARXPPHodD9II; ak9hvIpGt1CiE__s: echo $html->renderTemplate("\154\x6f\x61\144\55\x62\141\x6c\141\156\x63\145\162\x73\57\154\151\163\164\56\x68\164\x6d\154\56\164\167\x69\147", ["\164\151\x74\154\x65" => get_env("\x74\151\164\x6c\145"), "\141\x64\x6d\x69\156\137\144\x69\162" => ADMIN_DIR, "\165\x73\x65\137\x61\x63\x74\x69\166\145\x5f\x63\157\156\156\145\143\x74\151\157\156\x73" => validate_boolean(get_option("\163\145\x6c\145\143\164\x5f\x61\143\x74\x69\x76\x65\137\x63\157\x6e\156\145\143\164\151\157\x6e\163"))]); goto bh4m0bxZKbJIJtc5; GbCACEgQiJJSYbha: set_env("\164\x69\164\x6c\145", "\x4c\157\141\x64\x20\x42\141\154\141\156\x63\x65\162\x20\x53\x65\x72\166\x65\x72\163"); goto Z5NaaG30sCWtNQmv; bh4m0bxZKbJIJtc5: get_backend_footer();
