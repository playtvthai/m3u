<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto CXWpUDIrXcBhvsiy; CXWpUDIrXcBhvsiy: session_write_close(); goto aYgTvYMOovNloTZs; vr0n8Dq55I3w7olS: $html = new \GDPlayer\HTML(); goto KN8xLmzFXuCxZaWv; KTOnUJRLBft0nNNT: set_env("\164\151\164\x6c\145", "\122\x65\163\145\x74\40\x53\x65\164\x74\151\x6e\x67\163"); goto ypeOPzJG8y3VHof0; ypeOPzJG8y3VHof0: get_backend_header(); goto vr0n8Dq55I3w7olS; KN8xLmzFXuCxZaWv: echo $html->renderForm("\x73\145\164\164\151\156\x67\x73\55\x77\x72\x61\160\160\145\x72\x2e\150\164\x6d\x6c\x2e\x74\x77\151\147", ["\x72\x65\x73\x65\x74\x5f\146\157\x72\x6d" => "\x73\x65\164\x74\x69\156\x67\x73\57\x72\x65\x73\145\x74\x2e\x68\x74\x6d\x6c\56\164\167\x69\147", "\x61\144\155\x69\x6e\137\x64\151\x72" => ADMIN_DIR . "\57\x73\x65\x74\164\151\156\x67\163\57\x72\145\163\x65\x74\x2f"]); goto aFIpP7quqiZpzGNa; aYgTvYMOovNloTZs: include_once BASE_DIR . "\x69\156\x63\x6c\165\144\x65\x73\x2f\x73\x65\x74\164\x69\156\147\163\x2e\x70\x68\160"; goto KTOnUJRLBft0nNNT; aFIpP7quqiZpzGNa: get_backend_footer();
