<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto geeEa99BwYz2hzT8; geeEa99BwYz2hzT8: session_write_close(); goto aaA2lGaJToCWxURU; dpxgtPB8FW0Uv6kl: set_env("\164\151\x74\154\x65", "\126\151\x64\145\157\40\114\151\163\x74"); goto Pf6RNTxt2nsQxboX; HS7JwfVa16dZ3tvk: echo $html->renderTemplate("\x76\x69\144\x65\x6f\x73\57\x6c\x69\x73\x74\56\150\164\155\154\56\164\167\x69\x67", ["\164\151\164\154\x65" => get_env("\164\151\x74\x6c\x65"), "\142\141\163\145\x5f\165\162\x6c" => BASE_URL, "\x61\144\155\151\x6e\x5f\144\x69\x72" => ADMIN_DIR, "\x69\163\x5f\141\x64\x6d\151\156" => is_admin(), "\163\x75\160\160\157\x72\164\145\x64\x5f\163\x69\x74\145\163" => $supportedSites]); goto DSmyDSU4geo6S8Tu; Pf6RNTxt2nsQxboX: get_backend_header(); goto eGfKNLFSKPwSF_sn; UEoWQeEWfmbcKQnn: $html = new \GDPlayer\HTML(); goto HS7JwfVa16dZ3tvk; aaA2lGaJToCWxURU: include_once BASE_DIR . "\151\156\x63\x6c\x75\144\x65\x73\x2f\x69\x73\x55\x73\145\162\x2e\x70\x68\160"; goto dpxgtPB8FW0Uv6kl; eGfKNLFSKPwSF_sn: $supportedSites = supportedSites(); goto p4W4Y6aGRVgE7XSl; p4W4Y6aGRVgE7XSl: ksort($supportedSites, SORT_NATURAL); goto UEoWQeEWfmbcKQnn; DSmyDSU4geo6S8Tu: get_backend_footer();
