<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto Uw2dqwS3lrelFn7P; NBoMRD66KSZJPBg5: get_backend_header(); goto cw9XIH69rYTgFf6A; Uw2dqwS3lrelFn7P: session_write_close(); goto Aoj1E8ln3TzTR13D; Eq0zaksEWkIXmfeT: echo $html->renderTemplate("\x76\x69\144\x65\157\163\x2f\x73\165\142\x74\x69\164\x6c\x65\55\154\151\x73\164\x2e\x68\164\x6d\154\56\x74\167\151\147", ["\x74\151\x74\x6c\145" => get_env("\164\151\x74\154\x65"), "\151\163\x5f\x61\x64\x6d\x69\x6e" => is_admin(), "\x73\x75\x62\x74\151\164\x6c\145\163" => $subtitles, "\x62\141\x73\x65\137\x75\162\154" => BASE_URL]); goto uIsewxmO7fGWdust; Aoj1E8ln3TzTR13D: include_once BASE_DIR . "\151\156\143\x6c\x75\144\x65\x73\x2f\151\x73\x55\163\145\162\56\160\150\160"; goto nC7uopwQbmRqIfxw; qrMyAj2R7NtwfIeE: $subtitles = array_values($subtitles); goto sj43X4lZVVfCBd8M; nC7uopwQbmRqIfxw: $subtitles = language_list(); goto qrMyAj2R7NtwfIeE; cw9XIH69rYTgFf6A: $html = new \GDPlayer\HTML(); goto Eq0zaksEWkIXmfeT; sj43X4lZVVfCBd8M: set_env("\x74\151\x74\x6c\145", "\x53\165\142\164\151\164\154\145\x20\x4d\x61\156\141\x67\x65\x72"); goto NBoMRD66KSZJPBg5; uIsewxmO7fGWdust: get_backend_footer();
