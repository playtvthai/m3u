<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto LlWKzkjOzCSJHdfB; LlWKzkjOzCSJHdfB: session_write_close(); goto wIQI941zGHP5r15x; e_l8ysJKVOZu3PyB: echo get_env("\164\151\164\x6c\145"); goto ThIkNeAPShySPG8k; nD6hKAEmktCKc7Nt: get_backend_header(); goto EslE41LNXZpbsxTa; EslE41LNXZpbsxTa: echo "\x3c\x64\x69\x76\40\x63\x6c\141\163\x73\x3d\42\x72\x6f\x77\42\76\xa\x20\40\40\x20\x3c\144\151\x76\40\143\154\x61\163\163\75\42\x63\157\x6c\x2d\x31\x32\x20\164\145\x78\164\x2d\143\x65\156\x74\145\x72\42\76\xa\x20\40\40\x20\x20\x20\x20\40\x3c\x68\x31\40\143\x6c\141\x73\163\75\42\150\63\40\164\145\170\x74\x2d\144\141\156\x67\x65\162\42\76"; goto e_l8ysJKVOZu3PyB; wIQI941zGHP5r15x: set_env("\164\151\x74\154\145", "\64\x30\63\x20\x46\157\162\142\x69\144\x64\x65\156"); goto nD6hKAEmktCKc7Nt; ThIkNeAPShySPG8k: echo "\x3c\x2f\x68\x31\76\xa\40\40\x20\40\x20\40\40\40\x3c\150\x33\40\143\x6c\x61\163\x73\75\x22\x68\64\40\x74\x65\x78\x74\x2d\x73\145\143\x6f\156\x64\x61\162\171\42\76\131\x6f\x75\40\141\x72\x65\40\156\x6f\x74\40\x61\x6c\154\157\x77\x65\144\x20\x74\x6f\40\141\x63\x63\x65\163\163\40\x74\150\145\x20\160\x61\147\x65\56\x3c\x2f\x68\63\x3e\12\x20\40\x20\x20\x3c\57\x64\x69\166\x3e\xa\x3c\57\144\x69\x76\x3e\xa"; goto f5j1EmfpsHic5NRU; f5j1EmfpsHic5NRU: get_backend_footer();
