<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto Fg9INgmBUFXrU23V; nMgs6v9cVsLX2dRW: $html = new \GDPlayer\HTML(); goto WWq3VGA1CMva0iza; rfD3n7qWBmXPEIxH: set_env("\164\151\x74\x6c\x65", "\x50\154\165\x67\x69\156\163\40\114\151\163\164"); goto FHN4PLdUIi2b13hp; Fg9INgmBUFXrU23V: session_write_close(); goto sy23M513sGcOkKps; WWq3VGA1CMva0iza: echo $html->renderTemplate("\160\x6c\x75\147\151\x6e\55\154\151\163\164\x2e\x68\164\x6d\154\56\164\x77\x69\147", ["\x74\x69\x74\154\145" => get_env("\164\151\164\154\145")]); goto CcB2bMNnH1X7rXKE; sy23M513sGcOkKps: include_once BASE_DIR . "\x69\x6e\143\154\x75\144\145\163\x2f\x69\x73\101\x64\155\x69\156\x2e\x70\x68\x70"; goto rfD3n7qWBmXPEIxH; FHN4PLdUIi2b13hp: get_backend_header(); goto nMgs6v9cVsLX2dRW; CcB2bMNnH1X7rXKE: get_backend_footer();
