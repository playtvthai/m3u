<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto TzVVTCFOjJuKD2oJ; gInOdmGiQ5Wbvknz: echo "\74\x64\x69\x76\x20\x63\x6c\141\163\163\75\x22\x72\157\x77\42\76\xa\x20\40\x20\40\74\x64\151\x76\x20\x63\x6c\141\163\x73\x3d\x22\143\157\x6c\55\61\x32\40\164\x65\170\x74\x2d\143\145\x6e\164\x65\x72\42\x3e\xa\x20\x20\x20\x20\40\40\40\x20\x3c\x68\x31\40\143\x6c\141\163\x73\75\x22\150\x33\40\164\145\170\164\x2d\144\141\156\x67\x65\x72\42\x3e"; goto pPczUZgtkdkO4_nh; fdTWBcoTvvMW504c: get_backend_header(); goto gInOdmGiQ5Wbvknz; pPczUZgtkdkO4_nh: echo get_env("\x74\151\164\x6c\x65"); goto U2YPC9TEP2XjdYIg; U2YPC9TEP2XjdYIg: echo "\x3c\57\x68\x31\76\12\x20\40\x20\40\40\40\x20\40\x3c\x68\63\x20\x63\x6c\x61\163\163\75\x22\150\x34\x20\x74\x65\170\x74\55\x73\145\143\x6f\x6e\x64\141\x72\x79\42\x3e\x54\x68\x65\x20\160\141\147\145\40\171\x6f\165\40\x61\162\145\40\x6c\157\x6f\x6b\x69\156\x67\40\146\x6f\162\40\x77\x61\x73\40\156\x6f\x74\x20\x66\x6f\165\x6e\x64\x2e\74\x2f\x68\x33\76\12\40\40\x20\40\x3c\57\144\151\166\x3e\xa\74\57\144\151\x76\x3e\12"; goto mmlTKzBc_08kxilx; TzVVTCFOjJuKD2oJ: session_write_close(); goto qmAWZAag245RCnCW; qmAWZAag245RCnCW: set_env("\x74\151\x74\x6c\145", "\64\x30\x34\40\116\157\164\x20\x46\157\165\x6e\144"); goto fdTWBcoTvvMW504c; mmlTKzBc_08kxilx: get_backend_footer();
