<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto mpy9hAmgWWEFz_eo; TyZEztBK4vMARUfV: echo "\x3c\x64\151\x76\40\143\x6c\141\163\x73\75\42\162\x6f\167\x22\76\xa\x20\40\40\x20\74\x64\x69\166\x20\143\154\x61\x73\x73\75\x22\143\x6f\154\55\x31\x32\x20\164\145\x78\164\55\x63\145\156\x74\x65\x72\x22\76\12\40\40\x20\x20\x20\40\x20\x20\x3c\150\x31\x20\143\x6c\141\163\163\75\42\x68\63\40\x74\x65\x78\x74\55\144\141\x6e\147\x65\162\42\x3e"; goto IcjFVsz9LZtol3Ut; fmvIwyil81dIlBiV: echo "\x3c\x2f\x68\61\x3e\xa\40\40\x20\x20\x20\x20\x20\40\74\150\x33\x20\x63\154\141\163\x73\x3d\x22\150\64\40\x74\x65\x78\164\55\x73\x65\x63\x6f\156\x64\141\162\x79\x22\x3e\123\157\162\162\x79\40\x74\150\151\x73\40\x76\151\x64\x65\157\x20\x69\163\x20\x75\156\x61\x76\x61\x69\x6c\x61\142\x6c\145\56\74\57\x68\x33\76\xa\x20\x20\x20\40\74\x2f\144\x69\166\76\xa\x3c\x2f\x64\151\166\76\12"; goto tYZPHQX3J1pFI9_p; IcjFVsz9LZtol3Ut: echo get_env("\164\151\x74\x6c\145"); goto fmvIwyil81dIlBiV; mpy9hAmgWWEFz_eo: session_write_close(); goto yPT75DmQqDFhT8fF; TTQT7VWdJ68HHs5P: get_backend_header(); goto TyZEztBK4vMARUfV; yPT75DmQqDFhT8fF: set_env("\x74\x69\x74\x6c\145", "\x44\115\103\101\x20\x54\141\x6b\145\144\157\167\x6e"); goto TTQT7VWdJ68HHs5P; tYZPHQX3J1pFI9_p: get_backend_footer();
