<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto V7Y7yv1Kzx7x6vi1; jy9CrvtZPlOgMUwZ: set_env("\x74\151\x74\x6c\145", "\104\x61\x73\x68\142\x6f\x61\x72\144"); goto zdIr45ypEd6sUJFr; zdIr45ypEd6sUJFr: get_backend_header(); goto IiOnK1jcHg9qWnpY; KrSti_4Ln_Lws731: $server = new \GDPlayer\ServerInfo(); goto xJAPR8VzeQbbUF3E; yPECC8RCcMFrg4rk: include_once BASE_DIR . "\151\156\x63\x6c\165\x64\145\163\57\x69\163\125\x73\145\162\x2e\160\x68\160"; goto jy9CrvtZPlOgMUwZ; IiOnK1jcHg9qWnpY: $iCache = new \GDPlayer\InstanceCache(); goto KrSti_4Ln_Lws731; xJAPR8VzeQbbUF3E: $class = new \GDPlayer\HTML(); goto qoClCXp2lbwgvbOi; qoClCXp2lbwgvbOi: echo $class->renderTemplate("\144\x61\163\x68\142\x6f\141\x72\x64\56\x68\164\155\x6c\56\164\x77\x69\x67", ["\x74\151\x74\x6c\145" => get_env("\x74\151\164\x6c\x65"), "\x61\144\x6d\151\x6e\x5f\144\x69\x72" => ADMIN_DIR, "\151\x73\137\x61\x64\x6d\x69\156" => is_admin(), "\x68\x69\144\x65\x5f\145\x78\164\x5f\144\x69\x61\154\x6f\x67" => $iCache->get("\150\151\144\x65\137\x65\170\164\137\x64\151\x61\154\x6f\x67") ?? false]); goto EdZLs1fAgJcwCKH_; V7Y7yv1Kzx7x6vi1: session_write_close(); goto yPECC8RCcMFrg4rk; EdZLs1fAgJcwCKH_: get_backend_footer();
