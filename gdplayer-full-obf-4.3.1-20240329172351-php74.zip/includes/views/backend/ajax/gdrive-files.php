<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto RIi423BqKX2wD4EK; deE_ray0olTDPz60: $class = new \GDPlayer\Ajax\GDriveFile(); goto z1UuPDV7B2nz2C5p; RIi423BqKX2wD4EK: session_write_close(); goto deE_ray0olTDPz60; z1UuPDV7B2nz2C5p: echo $class->response($_POST);
