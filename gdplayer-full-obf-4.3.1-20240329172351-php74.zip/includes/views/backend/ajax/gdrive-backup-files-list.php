<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto acLlpxgjJ5JEqWho; Q5zPk43Ldy8WaD80: $class = new \GDPlayer\Ajax\GDriveMirror(); goto U3oA_70Vqwf2zBCZ; acLlpxgjJ5JEqWho: session_write_close(); goto Q5zPk43Ldy8WaD80; U3oA_70Vqwf2zBCZ: echo $class->list($_GET);
