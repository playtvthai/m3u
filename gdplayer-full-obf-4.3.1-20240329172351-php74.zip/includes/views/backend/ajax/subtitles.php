<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto luvv1JFslN93IODM; WvZNkJ3lV75ZiWKx: $class = new \GDPlayer\Ajax\Subtitle(); goto vzQX5qIjoVaJ0YFL; luvv1JFslN93IODM: session_write_close(); goto WvZNkJ3lV75ZiWKx; vzQX5qIjoVaJ0YFL: echo $class->response($_POST, $_FILES);
