<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto EgHcg9F_41NRqcgl; EgHcg9F_41NRqcgl: session_write_close(); goto mjxmFUWLwKhwZ2pv; mjxmFUWLwKhwZ2pv: $class = new \GDPlayer\Ajax\GDriveAccount(); goto Dq9uc2lThLhmOUQ2; Dq9uc2lThLhmOUQ2: echo $class->list($_GET);
