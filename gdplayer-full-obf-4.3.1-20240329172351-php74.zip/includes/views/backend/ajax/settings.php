<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto B5ieYvFe8Lt6Jb6N; B5ieYvFe8Lt6Jb6N: session_write_close(); goto ulCS4IR8aojhOUvK; ulCS4IR8aojhOUvK: $class = new \GDPlayer\Ajax\Setting(); goto cN3y2wCsOWzSZwfe; cN3y2wCsOWzSZwfe: echo $class->response($_POST);
