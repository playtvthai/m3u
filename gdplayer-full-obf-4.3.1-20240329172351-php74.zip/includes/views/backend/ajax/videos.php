<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto nNA8WNUim_9FmXgj; upqTzi6xmNPp2jT2: $class = new \GDPlayer\Ajax\Video(); goto HbuO2w8z1oVdrtT6; nNA8WNUim_9FmXgj: session_write_close(); goto upqTzi6xmNPp2jT2; HbuO2w8z1oVdrtT6: echo $class->response($_POST, $_FILES);
