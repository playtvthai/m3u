<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto VRZrPstfWl1e1nqq; VRZrPstfWl1e1nqq: session_write_close(); goto FmMrpY6E9H_70oCZ; FmMrpY6E9H_70oCZ: $class = new \GDPlayer\Ajax\GDriveQueue(); goto FBDUuq6Bcl8L0Esz; FBDUuq6Bcl8L0Esz: echo $class->response($_POST);
