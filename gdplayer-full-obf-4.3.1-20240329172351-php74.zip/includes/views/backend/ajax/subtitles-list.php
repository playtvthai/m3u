<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto YT20dOHPm0G4iG8Z; RAtIAs_Xmau_HLfD: $class = new \GDPlayer\Ajax\Subtitle(); goto gg9vyzPAWFaT3A_3; YT20dOHPm0G4iG8Z: session_write_close(); goto RAtIAs_Xmau_HLfD; gg9vyzPAWFaT3A_3: echo $class->list($_GET);
