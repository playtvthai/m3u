<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto huAO5X_mPw2xBWAN; yYZNYbg9mNYOE2Of: $class = new \GDPlayer\Ajax\User(); goto hZFgAv9m1gELxh0k; huAO5X_mPw2xBWAN: session_write_close(); goto yYZNYbg9mNYOE2Of; hZFgAv9m1gELxh0k: echo $class->list($_GET);
