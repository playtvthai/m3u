<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto WzXYLiaEkrUchzrh; WzXYLiaEkrUchzrh: session_write_close(); goto nR2tTEo27_5_l1sm; nR2tTEo27_5_l1sm: $class = new \GDPlayer\Ajax\GDriveQueue(); goto ik7Y5VbllNMonjDR; ik7Y5VbllNMonjDR: echo $class->list($_GET);
