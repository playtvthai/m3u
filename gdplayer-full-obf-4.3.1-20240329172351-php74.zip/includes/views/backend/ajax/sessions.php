<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto TAYX7NqFTaD0KLZk; TAYX7NqFTaD0KLZk: session_write_close(); goto uXHVrTsJQNMpFpg5; uXHVrTsJQNMpFpg5: $class = new \GDPlayer\Ajax\Session(); goto Ld3KjMQSR5kuIlu1; Ld3KjMQSR5kuIlu1: echo $class->response($_POST);
