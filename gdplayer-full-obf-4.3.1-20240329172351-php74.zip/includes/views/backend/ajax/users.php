<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto dfJT7gw9nig6PV5z; dfJT7gw9nig6PV5z: session_write_close(); goto geDlzPzzAr58vvx3; geDlzPzzAr58vvx3: $class = new \GDPlayer\Ajax\User(); goto Ffd4pcfResLZOjSY; Ffd4pcfResLZOjSY: echo $class->response($_POST);
