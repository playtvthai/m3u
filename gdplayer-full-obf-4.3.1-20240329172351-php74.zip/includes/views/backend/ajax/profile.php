<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto UHbmXyd8GYpHrq8H; UHbmXyd8GYpHrq8H: session_write_close(); goto AXST4RQD0v0Ulmvr; AXST4RQD0v0Ulmvr: $class = new \GDPlayer\Ajax\User(); goto ce392YDWiWW0bRpY; ce392YDWiWW0bRpY: echo $class->response($_POST);
