<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto WVD_YCzJKTE4DJLH; VdwC1TgNUkzCfeDL: $class = new \GDPlayer\Ajax\LoadBalancer(); goto nVX3bcpinaidaO5y; WVD_YCzJKTE4DJLH: session_write_close(); goto VdwC1TgNUkzCfeDL; nVX3bcpinaidaO5y: echo $class->list($_GET);
