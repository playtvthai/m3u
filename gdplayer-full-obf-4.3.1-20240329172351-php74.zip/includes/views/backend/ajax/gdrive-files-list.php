<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto WqnMkpf4ghB8Zr_a; WqnMkpf4ghB8Zr_a: session_write_close(); goto rDdWqgERT1oYEJHt; rDdWqgERT1oYEJHt: $class = new \GDPlayer\Ajax\GDriveFile(); goto cJbBOaUpOu4LZNzs; cJbBOaUpOu4LZNzs: echo $class->list($_GET);
