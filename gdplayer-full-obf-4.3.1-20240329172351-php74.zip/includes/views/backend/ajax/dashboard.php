<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto QVA4ZAtAPy3T10QO; usS5s2mQJsiJhONB: set_time_limit(0); goto wjuCncHHjwCBtuIV; wjuCncHHjwCBtuIV: $class = new \GDPlayer\Ajax\Dashboard(); goto MjIG_cSttuKvfNc9; QVA4ZAtAPy3T10QO: session_write_close(); goto usS5s2mQJsiJhONB; MjIG_cSttuKvfNc9: echo $class->response($_POST);
