<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto SNx_LGyj3JEtK0E_; xApBnCqtCbE5UV5j: include_once BASE_DIR . "\151\x6e\x63\154\165\x64\145\x73\57\151\163\101\144\x6d\x69\x6e\56\160\150\160"; goto jqOQpM_AiKEIUusi; VA2I1hCcg6yuw2WM: get_backend_header(); goto fxpr7Q7JswRiPc9i; md1OYdmBXPATqiIq: echo $html->renderTemplate("\x67\x64\162\151\166\x65\x2f\x62\x61\143\x6b\x75\160\55\146\x69\x6c\x65\x73\56\150\x74\155\x6c\56\x74\167\151\147", ["\164\x69\x74\x6c\145" => get_env("\164\x69\x74\154\145")]); goto ngHaXDQOd05p8tKm; SNx_LGyj3JEtK0E_: session_write_close(); goto xApBnCqtCbE5UV5j; jqOQpM_AiKEIUusi: set_env("\164\151\164\154\x65", "\x47\x6f\157\x67\x6c\x65\40\104\x72\151\166\145\40\x42\x61\x63\153\x75\x70\x20\106\x69\x6c\145\40\114\151\x73\x74"); goto VA2I1hCcg6yuw2WM; fxpr7Q7JswRiPc9i: $html = new \GDPlayer\HTML(); goto md1OYdmBXPATqiIq; ngHaXDQOd05p8tKm: get_backend_footer();
