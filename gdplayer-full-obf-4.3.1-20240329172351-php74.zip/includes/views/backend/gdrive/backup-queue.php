<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto c7Kwpely2uZG3uUV; hiJ5FFzPZJS2U2hl: $html = new \GDPlayer\HTML(); goto Qe7B6vqzbc0ioRNn; iQvcvWm34qisTe4R: set_env("\164\x69\164\x6c\x65", "\x47\157\157\147\154\x65\x20\x44\x72\151\166\x65\40\102\141\143\x6b\x75\x70\40\x51\x75\x65\165\145\x20\114\x69\x73\164"); goto XIiEZNb6RFmSTBtG; c7Kwpely2uZG3uUV: session_write_close(); goto aobsoL5Vs6GmYiq2; XIiEZNb6RFmSTBtG: get_backend_header(); goto hiJ5FFzPZJS2U2hl; Qe7B6vqzbc0ioRNn: echo $html->renderTemplate("\147\x64\162\x69\x76\x65\57\x62\x61\x63\x6b\165\x70\x2d\161\165\x65\165\145\x2e\150\x74\155\154\x2e\164\x77\151\x67", ["\x74\151\164\154\x65" => get_env("\x74\x69\164\x6c\x65")]); goto bH2X3oAGR37rUpZC; aobsoL5Vs6GmYiq2: include_once BASE_DIR . "\151\156\143\154\165\x64\145\163\x2f\151\x73\x41\144\155\151\x6e\x2e\x70\150\160"; goto iQvcvWm34qisTe4R; bH2X3oAGR37rUpZC: get_backend_footer();
