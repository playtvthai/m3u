<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto iRKOiSFK2PkWN7al; iRKOiSFK2PkWN7al: session_write_close(); goto QL5Uxz4fL0PIwGEq; gRDczABNB8d9BHiJ: get_backend_header(); goto JJOY98v05TwujMYG; lupy2tzt6nhL3SLZ: echo $html->renderTemplate("\x67\x64\x72\x69\x76\x65\57\141\143\x63\157\x75\x6e\164\55\x6c\151\163\164\56\x68\164\155\x6c\x2e\164\167\151\147", ["\164\151\164\x6c\145" => get_env("\164\x69\x74\x6c\x65"), "\x61\144\x6d\x69\156\x5f\x64\151\x72" => ADMIN_DIR]); goto fbOgohamcSFTFFFq; SmIN2OSSWL7w0fhy: set_env("\164\x69\164\154\x65", "\x47\x6f\157\x67\x6c\145\40\104\162\x69\x76\145\40\101\143\x63\x6f\x75\156\x74\x73"); goto gRDczABNB8d9BHiJ; QL5Uxz4fL0PIwGEq: include_once BASE_DIR . "\x69\156\x63\x6c\165\144\x65\x73\x2f\151\163\x41\144\155\151\156\x2e\160\x68\160"; goto SmIN2OSSWL7w0fhy; JJOY98v05TwujMYG: $html = new \GDPlayer\HTML(); goto lupy2tzt6nhL3SLZ; fbOgohamcSFTFFFq: get_backend_footer();
