<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto yugSXVbJLRwvx23S; YARcHH0325xxK9WU: $html = new \GDPlayer\HTML(); goto LghOCC25jTVoJmft; jCu2rBB7OmeJqq27: get_backend_header(); goto YARcHH0325xxK9WU; LghOCC25jTVoJmft: echo $html->renderTemplate("\165\x73\x65\x72\x73\57\x6c\x69\163\x74\56\150\x74\x6d\x6c\x2e\164\167\151\147", ["\164\151\164\154\x65" => get_env("\x74\x69\x74\154\x65"), "\x61\x64\155\151\156\x5f\x64\151\162" => ADMIN_DIR]); goto JKc41svnASVzQi9b; yugSXVbJLRwvx23S: session_write_close(); goto puR0uJ0XnyEpZyjU; puR0uJ0XnyEpZyjU: include_once BASE_DIR . "\x69\x6e\143\154\165\144\145\163\57\x69\x73\x41\144\155\x69\156\56\x70\x68\160"; goto MEZkGcm0gvtYdZPF; MEZkGcm0gvtYdZPF: set_env("\x74\151\164\x6c\x65", "\125\x73\x65\162\x20\x4c\x69\x73\x74"); goto jCu2rBB7OmeJqq27; JKc41svnASVzQi9b: get_backend_footer();
