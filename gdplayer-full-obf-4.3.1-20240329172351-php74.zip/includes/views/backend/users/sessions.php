<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto Fyz_Znu3I5PXGRpi; lxwixgP5thm2U_2_: get_backend_header(); goto h7PkZ9m8NBOtRjhv; Fyz_Znu3I5PXGRpi: session_write_close(); goto lxxQROJoGZmunzGq; kQ4fAllqFrY_H9K6: set_env("\x74\151\x74\x6c\145", "\123\x65\163\163\151\x6f\x6e\x20\114\x69\163\x74"); goto lxwixgP5thm2U_2_; M85V0YaNC01raE22: echo $html->renderTemplate("\x75\163\145\162\163\x2f\163\x65\x73\163\x69\x6f\x6e\x2d\154\x69\163\x74\x2e\150\x74\155\x6c\56\x74\x77\151\x67", ["\x74\x69\x74\154\x65" => get_env("\164\151\164\154\145"), "\141\144\155\151\x6e\137\x64\151\x72" => ADMIN_DIR]); goto RVklrunyePL2i3rb; h7PkZ9m8NBOtRjhv: $html = new \GDPlayer\HTML(); goto M85V0YaNC01raE22; lxxQROJoGZmunzGq: include_once BASE_DIR . "\151\x6e\x63\x6c\x75\144\145\x73\x2f\151\163\x41\x64\155\151\x6e\x2e\160\x68\x70"; goto kQ4fAllqFrY_H9K6; RVklrunyePL2i3rb: get_backend_footer();
