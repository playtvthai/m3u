<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto fXLjav15zWdRXb4o; jLt9vMn_ea84d5xT: $headers = corsResponseHeaders(true); goto yEP12FpBmx7BuTjF; fXLjav15zWdRXb4o: session_write_close(); goto jLt9vMn_ea84d5xT; Z9DG9s4ErKJxjglE: $headers[] = "\x43\157\156\164\145\156\x74\x2d\124\x79\x70\145\x3a\x20\141\160\x70\154\x69\143\141\x74\x69\x6f\x6e\57\x6a\163\x6f\156\x3b\x20\143\150\141\x72\163\145\164\75\x75\164\x66\55\x38"; goto WV01r7mywDzEla5W; w2YuP16XM1O9Jtws: $player = new \GDPlayer\Player($dl); goto azcd6DsOsM9jW22X; WV01r7mywDzEla5W: createResponseHeaders($headers); goto lLcAr3rh1s2IkyZi; yEP12FpBmx7BuTjF: $headers[] = "\x43\141\x63\x68\x65\55\103\157\156\164\x72\157\154\72\x20\x6e\x6f\x2d\x63\141\x63\150\145\54\40\x6e\x6f\x2d\163\x74\x6f\162\145\54\x20\x6d\165\163\x74\55\x72\x65\166\141\154\x69\144\141\164\145"; goto Z9DG9s4ErKJxjglE; lLcAr3rh1s2IkyZi: $dl = validate_boolean($_GET["\x64\154"] ?? false); goto w2YuP16XM1O9Jtws; azcd6DsOsM9jW22X: echo gzipResponse($dl ? $player->getDownloadPageConfig() : $player->getEmbedPageConfig());
