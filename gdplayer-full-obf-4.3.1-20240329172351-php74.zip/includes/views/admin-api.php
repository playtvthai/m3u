<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:37              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto pHSlF4jlLUZsSqB7; glmald5FnZ7HbAkj: $class = new \GDPlayer\Ajax\PrivateAjax(); goto fx7gPXFo9yb_TzIr; dyrDLcz6HZQB9RH5: createResponseHeaders(corsResponseHeaders()); goto vYRZNiSUKok2l0Gp; xUVE5ZtI7ZfGRunB: session_write_close(); goto eCgskmG1wCkNhR7p; fx7gPXFo9yb_TzIr: if (isset($_POST["\x61\x63\x74\151\157\156"])) { goto TzCZNflMjMkifoFI; } goto xUVE5ZtI7ZfGRunB; JoqtmlYAn0qhAfuC: goto fLU22fNTnIO7B2GD; goto SmvgBeBOg74xg76y; uQPyIWxOdlRl6QEJ: session_write_close(); goto xtnDhTPiTLLhu96i; SmvgBeBOg74xg76y: TzCZNflMjMkifoFI: goto uQPyIWxOdlRl6QEJ; pHSlF4jlLUZsSqB7: session_write_close(); goto dyrDLcz6HZQB9RH5; eCgskmG1wCkNhR7p: echo $class->notValid(); goto JoqtmlYAn0qhAfuC; xtnDhTPiTLLhu96i: echo $class->response($_POST); goto ZPpRi08JYJGyMHYS; vYRZNiSUKok2l0Gp: header("\x43\x61\x63\x68\x65\55\103\157\156\x74\x72\x6f\154\72\40\156\x6f\55\143\x61\x63\x68\x65\x2c\40\156\157\55\x73\164\157\x72\145\x2c\40\155\165\x73\164\x2d\162\x65\x76\141\154\151\144\141\164\x65", true); goto glmald5FnZ7HbAkj; ZPpRi08JYJGyMHYS: fLU22fNTnIO7B2GD:
