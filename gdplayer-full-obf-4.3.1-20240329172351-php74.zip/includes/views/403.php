<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:37              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto oySL02p6lrySxgcm; oVktvI0fkiFn76P2: echo get_env("\x74\x69\x74\154\145"); goto iFrfxJfF6scLy5e1; fvhBKLjnHuKTuKQq: echo "\x3c\x64\151\166\x20\143\154\141\163\x73\75\42\x72\x6f\x77\42\x3e\12\40\40\x20\x20\x3c\144\151\x76\40\x63\x6c\141\x73\x73\75\x22\143\x6f\x6c\55\x31\x32\40\164\145\x78\x74\x2d\143\145\x6e\164\145\162\42\76\xa\40\40\x20\x20\40\40\40\40\74\150\x31\x20\x63\x6c\x61\x73\163\75\x22\150\63\40\164\145\170\x74\x2d\144\141\156\147\145\x72\42\76"; goto oVktvI0fkiFn76P2; iFrfxJfF6scLy5e1: echo "\x3c\57\x68\61\76\12\40\40\x20\40\x20\x20\x20\x20\x3c\150\x33\x20\143\154\141\x73\x73\75\42\150\x34\40\x74\x65\170\164\x2d\x73\145\143\157\156\144\141\162\x79\42\76\131\x6f\x75\x20\x61\162\145\40\156\157\x74\40\141\154\x6c\157\x77\145\144\40\x74\157\x20\x61\143\143\145\163\163\40\164\150\x65\x20\160\141\x67\x65\x2e\x3c\x2f\150\63\76\12\40\x20\40\40\74\x2f\x64\x69\166\76\xa\x3c\57\x64\x69\166\76\12"; goto tE4hJ3V0od6JhGB1; B2zjTsfeEcFhQu3a: set_env("\164\151\164\154\x65", "\64\x30\x33\x20\x46\x6f\x72\x62\151\x64\144\x65\156"); goto gD1kk6ADu30EqIpW; gD1kk6ADu30EqIpW: get_frontend_header(); goto fvhBKLjnHuKTuKQq; oySL02p6lrySxgcm: session_write_close(); goto B2zjTsfeEcFhQu3a; tE4hJ3V0od6JhGB1: get_frontend_footer();
