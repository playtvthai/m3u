<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:37              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto Ngt5CxREaHp72BXo; Ngt5CxREaHp72BXo: if (defined("\102\101\123\x45\x5f\125\122\x4c")) { goto IV2nOxGkL6xsfOT6; } goto zwPvJvvbnCRgD3pp; zwPvJvvbnCRgD3pp: session_write_close(); goto DdskNiatbYtJJrQ_; NtlYSE36Zvv7oXyj: session_write_close(); goto wWMnO2zOMAxu6KNr; wWMnO2zOMAxu6KNr: $_POST = []; goto gk8yjDfa7cmsfhWv; DdskNiatbYtJJrQ_: exit("\101\143\x63\145\163\163\40\144\145\x6e\x69\145\x64"); goto T1DKefZX_tDXAyHO; T1DKefZX_tDXAyHO: IV2nOxGkL6xsfOT6: goto E7fofAfwkF5yj2OO; D4uzNo008uBQCKZm: if (!(!$security->mekNgumbe() && (isset($_SERVER["\122\105\121\x55\x45\123\124\137\125\x52\x49"]) && strpos($_SERVER["\x52\105\x51\x55\105\x53\124\x5f\125\122\x49"], "\57\x6c\x6f\147\151\x6e") === false) && (isset($_POST["\141\143\164\x69\157\x6e"]) && sanitize_html($_POST["\x61\143\x74\151\x6f\x6e"]) !== "\163\141\166\x65\x4c\x69\143\145\x6e\x73\x65"))) { goto dgN4oOkvrSn8o8YC; } goto NtlYSE36Zvv7oXyj; E7fofAfwkF5yj2OO: $security = new \GDPlayer\Security(); goto D4uzNo008uBQCKZm; gk8yjDfa7cmsfhWv: dgN4oOkvrSn8o8YC:
