<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:37              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto RoV59qHIn5q_a1Lt; Q0jKtJBK2PniMi7u: session_write_close(); goto dZGF3O62M4_AENSA; RdfQ91kYgrL7yTI9: if (is_admin()) { goto Sruybs8Z1WsiNL9w; } goto Q0jKtJBK2PniMi7u; Vxx1mw7OodlZN3aC: exit; goto zOgF7Dov7TzrXY7P; dZGF3O62M4_AENSA: include_once ADMIN_PATH . "\57\x34\60\x33\x2e\x70\150\160"; goto Vxx1mw7OodlZN3aC; RoV59qHIn5q_a1Lt: include_once __DIR__ . "\x2f\144\145\146\x69\x6e\145\144\x2e\x70\150\x70"; goto RdfQ91kYgrL7yTI9; zOgF7Dov7TzrXY7P: Sruybs8Z1WsiNL9w:
