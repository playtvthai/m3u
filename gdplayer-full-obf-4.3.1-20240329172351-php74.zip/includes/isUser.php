<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:37              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto CpMT8SyF9uWr6kLv; CpMT8SyF9uWr6kLv: include_once __DIR__ . "\x2f\144\x65\146\151\x6e\x65\144\56\160\x68\x70"; goto m7x_O9_f52_IOlep; gFEqSm9nyqtRYizG: include_once ADMIN_PATH . "\x2f\x34\60\x33\x2e\x70\150\160"; goto ZMgvOXFzDHOl_8j4; m7x_O9_f52_IOlep: $userLogin = current_user(); goto l4WPLkkmiut87aCD; l4WPLkkmiut87aCD: if ($userLogin) { goto D4OozC_U_mhq8HQe; } goto DiIr7GIIjGwHBgzS; DiIr7GIIjGwHBgzS: session_write_close(); goto gFEqSm9nyqtRYizG; ZMgvOXFzDHOl_8j4: exit; goto MtpapkIAkCPvr3di; MtpapkIAkCPvr3di: D4OozC_U_mhq8HQe:
