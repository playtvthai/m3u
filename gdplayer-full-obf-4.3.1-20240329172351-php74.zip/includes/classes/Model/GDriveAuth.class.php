<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:36              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class GDriveAuth extends \GDPlayer\Model { protected $table = "\x74\x62\x5f\x67\x64\162\151\166\145\x5f\141\165\x74\150"; protected $fields = ["\151\144", "\x65\155\x61\151\x6c", "\141\x70\x69\137\153\145\x79", "\143\154\x69\x65\x6e\x74\x5f\151\144", "\143\154\x69\x65\156\x74\137\163\145\143\x72\145\x74", "\x72\x65\146\162\145\x73\150\137\x74\x6f\153\x65\156", "\143\x72\x65\x61\164\145\x64", "\155\x6f\x64\x69\146\151\145\x64", "\x75\x69\144", "\163\x74\x61\x74\x75\163", "\142\171\x70\141\x73\163"]; protected $primaryKey = "\151\144"; public function __construct() { session_write_close(); parent::__construct(); } public function getUpdateQueries() { session_write_close(); return ["\101\x4c\124\x45\x52\x20\x54\101\102\114\105\x20\140\x74\x62\x5f\147\144\162\151\x76\145\137\x61\165\164\x68\140\40\x41\x44\x44\40\x43\117\114\x55\115\116\40\x60\142\171\x70\x61\x73\163\x60\x20\111\x4e\124\x28\x31\x29\x20\x4e\x4f\124\x20\x4e\125\x4c\114\40\104\105\106\101\x55\x4c\124\40\x27\x31\x27\73"]; } public function __destruct() { session_write_close(); parent::__destruct(); } }
