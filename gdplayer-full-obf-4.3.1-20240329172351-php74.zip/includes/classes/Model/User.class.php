<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:36              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class User extends \GDPlayer\Model { protected $table = "\164\142\x5f\165\163\145\x72\163"; protected $fields = ["\151\144", "\x75\163\x65\162", "\145\x6d\141\x69\x6c", "\160\141\163\x73\167\157\x72\144", "\x6e\141\155\x65", "\163\164\141\164\165\163", "\x61\144\x64\x65\x64", "\x75\160\x64\x61\x74\x65\144", "\162\x6f\154\x65"]; protected $primaryKey = "\151\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function getUpdateQueries() { session_write_close(); return ["\125\x50\104\x41\x54\x45\x20\140\164\142\x5f\165\x73\x65\x72\x73\140\x20\x53\105\124\x20\x60\x75\160\x64\141\x74\x65\144\140\x3d\x30\x20\127\x48\105\122\x45\40\140\x75\x70\144\141\x74\x65\144\x60\40\x49\x53\x20\x4e\x55\114\114\x3b", "\x41\114\124\105\122\40\x54\x41\102\114\105\40\140\x74\142\137\165\163\145\162\163\x60\x20\x4d\x4f\104\111\x46\x59\x20\x43\x4f\114\125\x4d\116\40\x60\165\x70\x64\x61\x74\145\144\140\x20\111\116\124\x28\61\65\51\x20\x4e\117\124\40\116\125\114\114\x20\104\105\x46\x41\x55\114\x54\40\47\x30\47\73"]; } public function __destruct() { session_write_close(); parent::__destruct(); } }
