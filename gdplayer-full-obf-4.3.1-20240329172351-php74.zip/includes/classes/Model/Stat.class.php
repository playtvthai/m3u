<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:36              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Stat extends \GDPlayer\Model { protected $table = "\x74\x62\x5f\163\164\141\164\x73"; protected $fields = ["\x76\151\144", "\151\160", "\x75\x61", "\143\x72\x65\141\x74\145\144"]; protected $primaryKey = ''; public function __construct() { session_write_close(); parent::__construct(); } public function getUpdateQueries() { session_write_close(); return ["\101\114\x54\x45\x52\40\x54\x41\x42\x4c\x45\40\x60\x74\x62\x5f\163\x74\141\164\163\x60\x20\104\122\x4f\x50\x20\x49\116\104\x45\130\x20\140\x50\122\111\x4d\101\x52\x59\x60\73", "\101\x4c\124\105\x52\x20\x54\x41\x42\x4c\105\x20\x60\164\142\x5f\x73\x74\141\x74\163\x60\x20\x44\122\117\x50\40\x43\117\x4c\x55\115\116\40\140\x69\x64\140\73", "\x43\122\105\x41\124\x45\x20\111\116\104\x45\130\40\x60\166\x69\x64\137\151\x64\x78\x60\40\x4f\x4e\40\x60\x74\x62\x5f\x73\164\x61\164\x73\x60\x28\x60\166\151\x64\x60\x29\x3b"]; } public function __destruct() { session_write_close(); parent::__destruct(); } }
