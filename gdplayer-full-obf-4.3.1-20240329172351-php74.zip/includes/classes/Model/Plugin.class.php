<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:36              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class Plugin extends \GDPlayer\Model { protected $table = "\x74\x62\x5f\x70\x6c\x75\x67\x69\x6e\x73"; protected $fields = ["\x69\144", "\x6b\145\171", "\166\x61\154\165\145", "\x75\x70\144\x61\x74\x65\x64"]; protected $primaryKey = "\151\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function getUpdateQueries() { session_write_close(); return ["\101\114\124\105\x52\x20\x54\x41\x42\114\105\40\140\164\x62\137\x70\x6c\165\147\x69\156\x73\x60\40\115\117\104\111\106\x59\x20\x43\x4f\x4c\125\x4d\116\x20\x60\151\x64\140\x20\102\x49\107\111\x4e\x54\x28\62\60\x29\40\116\117\124\40\x4e\125\114\114\x20\x41\x55\x54\x4f\x5f\111\116\103\122\105\115\105\116\124\x3b", "\125\120\104\101\x54\105\x20\x60\164\x62\x5f\x70\154\165\x67\151\x6e\163\x60\40\123\x45\124\x20\140\x76\x61\x6c\165\145\140\x3d\47\x27\40\127\x48\x45\x52\x45\40\x60\166\x61\154\x75\x65\140\40\x49\x53\x20\116\x55\x4c\114\x3b", "\x41\x4c\x54\105\122\x20\124\101\x42\114\105\x20\x60\x74\x62\137\160\154\165\x67\151\156\x73\x60\40\x4d\117\104\111\106\x59\x20\103\x4f\114\125\115\x4e\x20\140\166\x61\x6c\165\x65\140\40\x54\x45\x58\124\40\x4e\x4f\x54\x20\x4e\x55\x4c\x4c\73"]; } public function __destruct() { session_write_close(); parent::__destruct(); } }
