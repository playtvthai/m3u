<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class archive extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto ED9EfdyLVdY2HrfI; UzZXNK72qe9Bc0FP: parent::__construct($id, $dl, $hostname); goto wdhFuBYLDaYSzecN; ED9EfdyLVdY2HrfI: session_write_close(); goto UzZXNK72qe9Bc0FP; wdhFuBYLDaYSzecN: $this->getCFSources(); goto mvhmJ5Wp3wwAu6ll; mvhmJ5Wp3wwAu6ll: } public function __destruct() { session_write_close(); parent::__destruct(); } }
