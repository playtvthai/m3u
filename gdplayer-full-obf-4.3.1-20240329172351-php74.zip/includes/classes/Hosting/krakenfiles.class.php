<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class krakenfiles extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto b9i_KkdKoovpQ6LF; KFnk0WkJZKcaA_ih: $this->sources = array_map(function ($dt) { goto maWlYvdt3iE2HQFg; maWlYvdt3iE2HQFg: session_write_close(); goto Jmm0oECVSOZnANsJ; SOKip0I2lP7CCgBQ: return $dt; goto Tm7j7yknxvVLbLYo; Jmm0oECVSOZnANsJ: $dt["\146\x69\x6c\145"] = "\150\x74\x74\160\163\72" . htmlspecialchars_decode($dt["\x66\x69\x6c\x65"]); goto SOKip0I2lP7CCgBQ; Tm7j7yknxvVLbLYo: }, $this->sources); goto nT642tsQj03vD5Dn; x5FP1tYLm3n3_D50: $this->getDOMTitle($this->url, "\56\143\157\x69\156\x2d\151\156\x66\x6f\40\150\x35"); goto Wv2OfWNkxfg85iOE; Wv2OfWNkxfg85iOE: if (empty($this->sources)) { goto FiSr98HcB77dXFhP; } goto nFyab2X0sRbvj5rE; nFyab2X0sRbvj5rE: session_write_close(); goto KFnk0WkJZKcaA_ih; nT642tsQj03vD5Dn: FiSr98HcB77dXFhP: goto z4ygWKyQaKoE9r5Z; luq4lJ344qFrvfT8: parent::__construct($id, $dl, $hostname); goto x5FP1tYLm3n3_D50; b9i_KkdKoovpQ6LF: session_write_close(); goto luq4lJ344qFrvfT8; z4ygWKyQaKoE9r5Z: } public function __destruct() { session_write_close(); parent::__destruct(); } }
