<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:36              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class yadisk extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto jsjFBQgb9oEQx9VM; jsjFBQgb9oEQx9VM: session_write_close(); goto b7NOwIHH6auZHb5K; b7NOwIHH6auZHb5K: $this->baseURL = "\150\164\164\160\x73\x3a\x2f\x2f\x79\x61\x64\x69\x2e\163\153\x2f"; goto QKYo5nF0yq0krtT7; QKYo5nF0yq0krtT7: parent::__construct($id, $dl, $hostname); goto Znwes14k_sJJDtv0; Znwes14k_sJJDtv0: $this->getCFSources(); goto p2ymD4XDAGtPE9nY; p2ymD4XDAGtPE9nY: } public function __destruct() { session_write_close(); parent::__destruct(); } }
