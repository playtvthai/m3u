<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class filelions extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto Zb5R65SM2bfeEK_H; OvEqZJRSwJ6RaTUF: $this->url = $this->baseURL . "\x76\57" . $id; goto i0cHu4CNSDrJDvfH; i0cHu4CNSDrJDvfH: parent::__construct($id, $dl, $hostname); goto c_1TrKaaT11jDSiS; Zb5R65SM2bfeEK_H: session_write_close(); goto vDBEnwSdWfchZeTA; vDBEnwSdWfchZeTA: $this->baseURL = "\150\164\x74\160\x73\72\x2f\x2f\166\151\x64\150\151\144\145\160\162\x6f\56\143\157\155\x2f"; goto OvEqZJRSwJ6RaTUF; c_1TrKaaT11jDSiS: $this->getDOMTitle($this->baseURL . "\x66\x2f" . $this->id, "\x68\61\56\x68\x34"); goto quMrK0MUHacp_em_; quMrK0MUHacp_em_: } public function __destruct() { session_write_close(); parent::__destruct(); } }
