<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class streamff extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto tYU0whiiHzMOSgpA; tYU0whiiHzMOSgpA: session_write_close(); goto wd0_J7emjXeQe4h8; wd0_J7emjXeQe4h8: parent::__construct($id, $dl, $hostname); goto Esa2J0N6KC4E3mVV; Esa2J0N6KC4E3mVV: $this->getCFSources(); goto YZlaBm4lPgNgxNmK; YZlaBm4lPgNgxNmK: } public function __destruct() { session_write_close(); parent::__destruct(); } }
