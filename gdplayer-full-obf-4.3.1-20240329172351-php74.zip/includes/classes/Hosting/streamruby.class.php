<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class streamruby extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto w6LCFohF4sWATWi5; w6LCFohF4sWATWi5: session_write_close(); goto ybXma6fYIQgLCwqz; XvghQLHToXjEGaFy: $this->getDOMTitle($this->url, "\x68\x32\x2e\166\124\151\164\x6c\x65"); goto v4zZahPim3zWBUwD; ybXma6fYIQgLCwqz: parent::__construct($id, $dl, $hostname); goto XvghQLHToXjEGaFy; v4zZahPim3zWBUwD: } public function __destruct() { session_write_close(); parent::__destruct(); } }
