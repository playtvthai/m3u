<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class vidlook extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto XLyJQNRBM9MFxghm; L2zYLawxtJiD51h9: $this->url = $this->baseURL . "\x65\x6d\x62\145\x64\55" . $id . "\56\x68\x74\x6d\154"; goto emLCOQgcfZVbgPnT; emLCOQgcfZVbgPnT: parent::__construct($id, $dl, $hostname); goto Z24l8MoX3g8e7Ieg; Cz4QJX5VG9WMsSUk: $this->baseURL = "\x68\164\x74\160\x73\72\x2f\x2f\x76\x69\144\154\157\157\x6b\56\x6e\145\x74\x2f"; goto L2zYLawxtJiD51h9; XLyJQNRBM9MFxghm: session_write_close(); goto Cz4QJX5VG9WMsSUk; Z24l8MoX3g8e7Ieg: $this->getDOMTitle($this->baseURL . $id); goto VEHfWdv5trioC40k; VEHfWdv5trioC40k: } public function __destruct() { session_write_close(); parent::__destruct(); } }
