<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class uqload extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto xdqpY3QeXIWN3cls; NqsAax4mUSWKvnyg: parent::__construct($id, $dl, $hostname); goto B8hXhRfXGAgaKQ5z; xdqpY3QeXIWN3cls: session_write_close(); goto NjfPd2M1XlUaQzlU; T0GldwUUereRrZqm: $this->url = $this->baseURL . "\x65\155\x62\145\144\55" . $id . "\56\x68\164\x6d\154"; goto NqsAax4mUSWKvnyg; NjfPd2M1XlUaQzlU: $this->baseURL = "\150\x74\x74\x70\163\72\x2f\x2f\165\161\x6c\x6f\x61\x64\56\143\x6f\155\57"; goto T0GldwUUereRrZqm; B8hXhRfXGAgaKQ5z: } public function __destruct() { session_write_close(); parent::__destruct(); } }
