<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class upstream extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto IXYUM2erCAGGS6Jm; TbMn1ZyjwfulcIUh: parent::__construct($id, $dl, $hostname); goto m1wisWrKCOu1_SGu; m1wisWrKCOu1_SGu: $this->getDOMTitle($this->url, "\x68\x31\56\164\x65\x78\x74\55\x77\x68\x69\164\x65"); goto m9h38_wY0MEnN6aO; IXYUM2erCAGGS6Jm: session_write_close(); goto TbMn1ZyjwfulcIUh; m9h38_wY0MEnN6aO: } public function __destruct() { session_write_close(); parent::__destruct(); } }
