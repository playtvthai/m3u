<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class supervideo extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto jJsRRjYZa2Hu1YhB; vgr2d_h7I23aUPcT: $this->getDOMTitle($this->url, "\150\x31\56\x64\157\x77\x6e\154\157\141\x64\137\x5f\164\x69\164\x6c\x65"); goto LENtJhkN4bOaFJ9h; jJsRRjYZa2Hu1YhB: session_write_close(); goto N1U5Wnj7eLwDljBZ; N1U5Wnj7eLwDljBZ: parent::__construct($id, $dl, $hostname); goto vgr2d_h7I23aUPcT; LENtJhkN4bOaFJ9h: } public function __destruct() { session_write_close(); parent::__destruct(); } }
