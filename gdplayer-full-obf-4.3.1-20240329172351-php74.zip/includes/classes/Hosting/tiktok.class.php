<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class tiktok extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto ZiLMMx9lysxFooXu; chALxBtodgk3sbbe: $this->id = end($ex); goto vqccd8IHkqCpPo5v; AdAVkw9nsQgNS76N: $ex = explode("\x2f", trim($this->id, "\x2f")); goto chALxBtodgk3sbbe; ZiLMMx9lysxFooXu: session_write_close(); goto g4qDu7qJjX7dtzZ8; vqccd8IHkqCpPo5v: $this->getCFSources(); goto OBKey5XZn8HsZ0mw; g4qDu7qJjX7dtzZ8: parent::__construct($id, $dl, $hostname); goto AdAVkw9nsQgNS76N; OBKey5XZn8HsZ0mw: } public function __destruct() { session_write_close(); parent::__destruct(); } }
