<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class vidoza extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto a8tKQW8KWLUyF575; BtTVTNynLy73YyHF: parent::__construct($id, $dl, $hostname); goto ypKn5imVKjzWZBo_; s6cPME7WHCGNjLBt: $this->baseURL = "\150\x74\x74\x70\163\x3a\57\57\x76\x69\144\x6f\172\141\x2e\156\145\x74\x2f"; goto EChLLj8PlMuOFpN1; EChLLj8PlMuOFpN1: $this->url = $this->baseURL . "\x65\x6d\142\145\x64\55" . $id . "\x2e\150\x74\155\154"; goto BtTVTNynLy73YyHF; a8tKQW8KWLUyF575: session_write_close(); goto s6cPME7WHCGNjLBt; ypKn5imVKjzWZBo_: } public function __destruct() { session_write_close(); parent::__destruct(); } }
