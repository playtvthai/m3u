<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class hxfile extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto OIk82ImBUBc3wYon; qY7Z3FkR_v0Izdit: parent::__construct($id, $dl, $hostname); goto gmyVuZlqoEXdsVRZ; gmyVuZlqoEXdsVRZ: $this->getDOMTitle($this->url, "\56\144\x66\151\x6c\x65\40\x3e\x20\56\x64\x66\x69\x6c\x65\x6e\141\155\145"); goto qvmkezah86DUAlta; OIk82ImBUBc3wYon: session_write_close(); goto qY7Z3FkR_v0Izdit; qvmkezah86DUAlta: } public function __destruct() { session_write_close(); parent::__destruct(); } }
