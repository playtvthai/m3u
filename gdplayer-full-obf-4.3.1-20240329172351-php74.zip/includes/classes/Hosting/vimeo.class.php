<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:36              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class vimeo extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto NlyrxOCfxUANEAGI; VVR_HarzDyrWVshu: $this->getCFSources(); goto YmHSQJU35kY2Z6Rc; E7Mc0h7TCK6epEOe: parent::__construct($id, $dl, $hostname); goto VVR_HarzDyrWVshu; NlyrxOCfxUANEAGI: session_write_close(); goto m1peLmVZfzLnU58C; m1peLmVZfzLnU58C: $this->baseURL = "\x68\164\x74\x70\163\x3a\57\x2f\166\x69\x6d\145\157\56\143\x6f\x6d\x2f"; goto E7Mc0h7TCK6epEOe; YmHSQJU35kY2Z6Rc: } public function __destruct() { session_write_close(); parent::__destruct(); } }
