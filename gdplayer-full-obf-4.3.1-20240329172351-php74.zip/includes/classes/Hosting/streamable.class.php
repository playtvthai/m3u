<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class streamable extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto tKK_4mNdnpdx7lpk; tKK_4mNdnpdx7lpk: session_write_close(); goto eb6QrRrTKo95GXPe; eb6QrRrTKo95GXPe: parent::__construct($id, $dl, $hostname); goto CzAx26CsfEKW00Z9; CzAx26CsfEKW00Z9: $this->getCFSources(); goto i32Qoaj2KMuwyW23; i32Qoaj2KMuwyW23: } public function __destruct() { session_write_close(); parent::__destruct(); } }
