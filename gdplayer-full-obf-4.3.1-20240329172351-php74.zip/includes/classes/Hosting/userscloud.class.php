<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class userscloud extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto E3vqjrg107YO_Dnf; E3vqjrg107YO_Dnf: session_write_close(); goto WKljHk4Gr1lwd8FP; SN_g1GpwwXDdCnM1: parent::__construct($id, $dl, $hostname); goto LsQqvxft9ZXyHIVi; tVrWYImW1msEHjrA: $this->url = $this->baseURL . $id; goto SN_g1GpwwXDdCnM1; WKljHk4Gr1lwd8FP: $this->baseURL = "\x68\x74\164\x70\163\72\x2f\57\x75\163\x65\x72\163\x63\154\157\x75\144\56\143\x6f\x6d\x2f"; goto tVrWYImW1msEHjrA; LsQqvxft9ZXyHIVi: } public function __destruct() { session_write_close(); parent::__destruct(); } }
