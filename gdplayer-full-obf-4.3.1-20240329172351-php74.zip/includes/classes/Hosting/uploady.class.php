<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class uploady extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto BBXtcYX3o0msuq_u; ja3h7uTSDtXVTQiF: parent::__construct($id, $dl, $hostname); goto exKDTEHIHgBht680; exKDTEHIHgBht680: $this->getDOMTitle($this->url); goto Wq_l7JfP2G3MhuO4; BBXtcYX3o0msuq_u: session_write_close(); goto ja3h7uTSDtXVTQiF; Wq_l7JfP2G3MhuO4: } public function __destruct() { session_write_close(); parent::__destruct(); } }
