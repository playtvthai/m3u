<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class mixdropto extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto JqjpQyxL9DQBJE_j; zoRerRhXwQWy1BVX: $this->url = "\x68\164\x74\160\x73\72\57\x2f\155\x69\x78\144\x72\x6f\160\x32\x31\x2e\x6e\145\164\x2f\145\57" . $id; goto txpvvygCmMfGPPit; s8wi4EZnSOmhdQ2k: $this->getDOMTitle(strtr($this->url, ["\x2f\x65\57" => "\x2f\x66\57"])); goto IopTwcp21cLP9ECB; txpvvygCmMfGPPit: parent::__construct($id, $dl, $hostname); goto s8wi4EZnSOmhdQ2k; JqjpQyxL9DQBJE_j: session_write_close(); goto zoRerRhXwQWy1BVX; IopTwcp21cLP9ECB: } public function __destruct() { session_write_close(); parent::__destruct(); } }
