<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class fireload extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto R27bLYM5GVQ3Nqfv; Z4LcxLyAIsysAFug: parent::__construct($id, $dl, $hostname); goto FtLxl0IAEmdr2smw; F3VhR1tJAhgv2Z2o: sleep(6); goto HmZyP69_OQ2k8By_; HmZyP69_OQ2k8By_: $this->sources = $this->getNewSources($this->sources); goto q9Q_YfdN0Wnx5xnS; J3RngBywVaygBPqC: if (empty($this->sources)) { goto lpIiEBSSNSxYGmzM; } goto GtT9EQPAztMkeYth; FtLxl0IAEmdr2smw: $this->getCFSources(); goto J3RngBywVaygBPqC; GtT9EQPAztMkeYth: session_write_close(); goto F3VhR1tJAhgv2Z2o; q9Q_YfdN0Wnx5xnS: lpIiEBSSNSxYGmzM: goto eEfOULYelNJFtaNk; R27bLYM5GVQ3Nqfv: session_write_close(); goto Z4LcxLyAIsysAFug; eEfOULYelNJFtaNk: } public function __destruct() { session_write_close(); parent::__destruct(); } }
