<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class vidpro extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto zSMq4EcXIGuHLNCx; WitCbe1mCEUoItoj: $this->getDOMTitle($this->baseURL . $id); goto SDnCM7UCTft1AmM7; MKqqkaSPfhuRe6Xu: $this->url = $this->baseURL . "\x65\155\x62\145\x64\55" . $id . "\56\x68\164\x6d\x6c"; goto pGuaZZbGumltodJf; pGuaZZbGumltodJf: parent::__construct($id, $dl, $hostname); goto WitCbe1mCEUoItoj; f6niqsJmSTbPJXYv: $this->baseURL = "\150\x74\164\x70\163\72\x2f\57\166\151\144\x70\162\157\x2e\x6e\145\x74\57"; goto MKqqkaSPfhuRe6Xu; zSMq4EcXIGuHLNCx: session_write_close(); goto f6niqsJmSTbPJXYv; SDnCM7UCTft1AmM7: } public function __destruct() { session_write_close(); parent::__destruct(); } }
