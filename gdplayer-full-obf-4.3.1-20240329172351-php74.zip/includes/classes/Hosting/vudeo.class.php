<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:36              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class vudeo extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto DmwfCkSjwhNvBQt9; DmwfCkSjwhNvBQt9: session_write_close(); goto Ja6qTBv86v3F8D3N; IaNjRkwyv76dYDK6: parent::__construct($id, $dl, $hostname); goto sSALWVSKRUHH_vFV; Ja6qTBv86v3F8D3N: $this->url = "\x68\164\x74\160\163\x3a\x2f\57\x76\x75\x64\x65\157\56\167\x73\x2f" . $id; goto IaNjRkwyv76dYDK6; sSALWVSKRUHH_vFV: } public function __destruct() { session_write_close(); parent::__destruct(); } }
