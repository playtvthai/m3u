<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class darkibox extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto LbN8F2qfUuAwbcS0; RO2VA0pFdyZk5iRt: parent::__construct($id, $dl, $hostname); goto IIuyUzwVBWecUWOC; LbN8F2qfUuAwbcS0: session_write_close(); goto P6qoN5I3nvQCtjYw; P6qoN5I3nvQCtjYw: $this->baseURL = "\x68\164\x74\160\163\x3a\57\x2f\x64\x61\x72\x6b\x69\x62\157\x78\x2e\143\x6f\x6d\57"; goto RO2VA0pFdyZk5iRt; IIuyUzwVBWecUWOC: $this->getDOMTitle($this->baseURL . $this->id . "\56\x68\164\155\x6c", "\150\62"); goto C2wJlyIS0Vw3VGNN; C2wJlyIS0Vw3VGNN: } public function __destruct() { session_write_close(); parent::__destruct(); } }
