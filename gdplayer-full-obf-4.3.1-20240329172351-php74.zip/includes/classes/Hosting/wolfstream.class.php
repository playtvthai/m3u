<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:36              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class wolfstream extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto HCWdJXyEqDRCkTQU; p02EIkuqtzYH55DU: $this->getDOMTitle($this->baseURL . "\x64\57" . $id, "\164\141\x62\154\145\56\164\142\154\x31\x20\164\150"); goto oZi3DtX7ffHNeEyf; OEA7fEhlxhQIDMI1: $this->url = $this->baseURL . "\145\155\142\x65\x64\55" . $id . "\56\150\164\x6d\x6c"; goto pfjj60SjBwIYNw5m; HCWdJXyEqDRCkTQU: session_write_close(); goto dOw3gTunqBFhn0Dl; pfjj60SjBwIYNw5m: parent::__construct($id, $dl, $hostname); goto p02EIkuqtzYH55DU; dOw3gTunqBFhn0Dl: $this->baseURL = "\150\164\164\160\x73\72\x2f\x2f\x77\157\154\146\163\x74\x72\x65\x61\155\56\164\x76\x2f"; goto OEA7fEhlxhQIDMI1; oZi3DtX7ffHNeEyf: } public function __destruct() { session_write_close(); parent::__destruct(); } }
