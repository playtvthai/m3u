<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class lulustream extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto aMhsC7KlGyMoQT58; aMhsC7KlGyMoQT58: session_write_close(); goto ZgjhE_HEAm_pC5mY; ZgjhE_HEAm_pC5mY: parent::__construct($id, $dl, $hostname); goto KM5QBiOcIGyZjFHA; KM5QBiOcIGyZjFHA: $this->getDOMTitle($this->url, "\150\x31\56\x68\x35"); goto eRWx0Xr0OFQYDYQU; eRWx0Xr0OFQYDYQU: } public function __destruct() { session_write_close(); parent::__destruct(); } }
