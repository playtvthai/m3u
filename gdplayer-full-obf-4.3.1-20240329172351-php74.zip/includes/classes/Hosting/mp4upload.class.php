<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class mp4upload extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto gsZiEMlgOdmb42Mz; i7ljVXdLCf0TrgCN: $this->getDOMTitle($this->url, "\56\146\151\x6c\x65\x2d\x69\x6e\146\157\x20\x2e\x6e\x61\155\x65\40\150\64"); goto JfeTndU29Y23kib2; gsZiEMlgOdmb42Mz: session_write_close(); goto HCct8KBqyudpxojy; HCct8KBqyudpxojy: parent::__construct($id, $dl, $hostname); goto i7ljVXdLCf0TrgCN; JfeTndU29Y23kib2: } public function __destruct() { session_write_close(); parent::__destruct(); } }
