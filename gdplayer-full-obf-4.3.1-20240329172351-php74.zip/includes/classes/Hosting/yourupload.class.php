<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:36              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class yourupload extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto wVR4OkV2NQvHEF1N; HWZFZzPZKijez_gL: session_write_close(); goto sSesVPTzdb0asDWg; lGVf13ltJLUIEwQA: $this->sources = $this->getNewSources($this->sources); goto NxXQBQ7veaGWXQ9s; sSesVPTzdb0asDWg: $this->sources[0]["\x66\151\154\145"] = "\x68\x74\x74\160\163\x3a\57\x2f\167\167\x77\56\171\x6f\165\x72\165\x70\x6c\157\141\144\x2e\x63\157\155" . $this->sources[0]["\x66\151\x6c\145"]; goto lGVf13ltJLUIEwQA; U0XNJ6mqdtMo5S_p: $this->getCFSources(); goto wK1gnJDL9trF09bh; wVR4OkV2NQvHEF1N: session_write_close(); goto hREnKopT9ZX94QtM; NxXQBQ7veaGWXQ9s: o1L3gn1CaiP4Il_U: goto er61OAwhwv_m4S28; wK1gnJDL9trF09bh: if (!(!empty($this->sources) && strpos($this->sources[0]["\146\x69\x6c\145"], "\x2f\x6e\x6f\166\x69\x64\145\x6f") !== false)) { goto o1L3gn1CaiP4Il_U; } goto HWZFZzPZKijez_gL; hREnKopT9ZX94QtM: parent::__construct($id, $dl, $hostname); goto U0XNJ6mqdtMo5S_p; er61OAwhwv_m4S28: } public function __destruct() { session_write_close(); parent::__destruct(); } }
