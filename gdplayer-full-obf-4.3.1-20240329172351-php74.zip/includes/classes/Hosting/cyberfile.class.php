<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class cyberfile extends \GDPlayer\YetiShare { public function __construct($id, $dl, $hostname) { session_write_close(); parent::__construct($id, $dl, $hostname); } public function __destruct() { session_write_close(); parent::__destruct(); } }
