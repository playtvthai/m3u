<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class aparat extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto YnIW7eHJlla8MTVD; U0mrrowtLIUpb8xB: parent::__construct($id, $dl, $hostname); goto r8Eqhq0x7tKk7SGF; r8Eqhq0x7tKk7SGF: $this->getCFSources(); goto PLj0B2fHphTCEBjB; YnIW7eHJlla8MTVD: session_write_close(); goto U0mrrowtLIUpb8xB; PLj0B2fHphTCEBjB: } public function __destruct() { session_write_close(); parent::__destruct(); } }
