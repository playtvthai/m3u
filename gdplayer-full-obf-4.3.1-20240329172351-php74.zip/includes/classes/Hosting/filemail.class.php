<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class filemail extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto sCn4u2CwPN_TwbFd; sCn4u2CwPN_TwbFd: session_write_close(); goto o0Uls0z0nNQWKsNR; j34aF5bCHkpZeDmS: $this->getCFSources(); goto xUZXGJDwHkV9KuCt; o0Uls0z0nNQWKsNR: parent::__construct($id, $dl, $hostname); goto j34aF5bCHkpZeDmS; xUZXGJDwHkV9KuCt: } public function __destruct() { session_write_close(); parent::__destruct(); } }
