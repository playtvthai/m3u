<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:35              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class dropden extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto ido4ptpSmmfDa83z; IgpNojXRjqGUj7U7: $this->getCFSources(); goto EpOqmaQDzITX1jPg; ido4ptpSmmfDa83z: session_write_close(); goto m_hUX0evluFnd6z8; m_hUX0evluFnd6z8: parent::__construct($id, $dl, $hostname); goto IgpNojXRjqGUj7U7; EpOqmaQDzITX1jPg: } public function __destruct() { session_write_close(); parent::__destruct(); } }
