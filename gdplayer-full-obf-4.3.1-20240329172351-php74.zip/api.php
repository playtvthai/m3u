<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-03-28 07:11:34              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto eyj2IhXCukbvef8j; eyj2IhXCukbvef8j: session_write_close(); goto DSydQjfYHRki0d2T; DSydQjfYHRki0d2T: include_once "\151\156\143\154\165\144\145\x73\57\x69\156\x63\154\165\144\x65\163\x2e\x70\x68\160"; goto bsRtgLBf6jMh3UUg; bsRtgLBf6jMh3UUg: include_once "\151\x6e\143\x6c\165\x64\x65\163\x2f\x76\x69\x65\x77\163\x2f\x61\160\151\x2e\160\x68\x70";
