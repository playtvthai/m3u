<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}
$plugins = new \GDPlayer\Plugins();
$widget = new \GDPlayer\Widget();
$userLogin = current_user();
$isAdmin = $userLogin && intval($userLogin['role']) === 0;
$themeColor = '#' . (get_option('pwa_themecolor') ?? '673ab7');
$isDarkMode = !empty($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark';

$urlParser = parse_url(BASE_URL);
header("Access-Control-Allow-Origin: {$urlParser['scheme']}://{$urlParser['host']}");
header('Access-Control-Allow-Credentials: true');
header('X-Frame-Options: SAMEORIGIN');

ob_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <base href="<?php echo BASE_URL; ?>">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="msapplication-TileColor" content="<?php echo $themeColor; ?>">
    <meta name="theme-color" content="<?php echo $themeColor; ?>">
    <meta name="apple-mobile-web-app-capable" content="yes">

    <meta name="description" content="<?php echo get_env('description'); ?>">

    <!-- facebook -->
    <meta name="og:sitename" content="<?php echo get_env('site_name'); ?>">
    <meta name="og:title" content="<?php echo get_env('title'); ?>">
    <meta name="og:description" content="<?php echo get_env('description'); ?>">
    <meta name="og:type" content="<?php echo get_env('page_type'); ?>">
    <meta name="og:image" content="<?php echo get_env('poster'); ?>">

    <!-- twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo get_env('title'); ?>">
    <meta name="twitter:description" content="<?php echo get_env('description'); ?>">
    <meta name="twitter:image" content="<?php echo get_env('poster'); ?>">

    <link rel="manifest" href="manifest.webmanifest">
    <link rel="mask-icon" href="https://cdn.jsdelivr.net/gh/adis0308/gdp/img/maskable_icon.png" color="#ffffff">

    <link rel="shortcut icon" href="favicon.ico" type="image/ico">
    <link rel="apple-touch-icon" href="assets/img/apple-touch-icon.png">
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/img/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/img/apple-touch-icon-152x152-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/img/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/img/apple-touch-icon-120x120-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/img/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/img/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/img/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon-precomposed" href="assets/img/apple-touch-icon.png">
    <link rel="apple-touch-icon-precomposed" href="assets/img/apple-touch-icon-precomposed.png">

    <title><?php echo get_env('title') . ' - ' . get_env('site_name'); ?></title>

    <link rel="preconnect dns-prefetch" href="//<?php echo $urlParser['host']; ?>">
    <link rel="preconnect dns-prefetch" href="//cdn.jsdelivr.net">
    <link rel="preconnect dns-prefetch" href="//cdnjs.cloudflare.com">
    <link rel="preconnect dns-prefetch" href="//cdn.datatables.net">
    <link rel="preconnect dns-prefetch" href="//www.gstatic.com">
    <link rel="preconnect dns-prefetch" href="//fonts.gstatic.com">
    <link rel="preconnect dns-prefetch" href="//www.googleapis.com">
    <link rel="preconnect dns-prefetch" href="//www.googletagmanager.com">
    <link rel="preconnect dns-prefetch" href="//www.google.com">
    <link rel="preconnect dns-prefetch" href="//www.google-analytics.com">
    <link rel="preconnect dns-prefetch" href="//googleusercontent.com">
    <link rel="preconnect dns-prefetch" href="//lh3.googleusercontent.com">
    <link rel="preconnect dns-prefetch" href="//drive-thirdparty.googleusercontent.com">
    <link rel="preconnect dns-prefetch" href="//static.addtoany.com">

    <?php
    $cssLinks = $plugins->getFrontendCSS(true);
    if ($cssLinks) {
        session_write_close();
        echo $cssLinks;
    }
    include_once FRONTEND_THEME_PATH . DIRECTORY_SEPARATOR . 'styles.php';

    echo $widget->loadCdnJsScript('jquery/3.7.0/jquery.min.js', false);
    echo $widget->loadScript('assets/vendor/FormData.js', false);
    ?>
    <script>
        var $ = jQuery.noConflict(),
            adminURL = '<?php echo ADMIN_URL; ?>/',
            baseURL = '<?php echo BASE_URL; ?>',
            imgCDNURL = baseURL,
            uid = <?php echo $userLogin ? $userLogin['id'] : 0; ?>,
            email = '<?php echo $userLogin ? $userLogin['email'] : ''; ?>',
            languages = <?php echo json_encode(array_values(language_list())); ?>,
            showModalUpdate = false,
            oldDBVersion = <?php echo intval(get_option('updated')); ?>,
            newDBVersion = <?php echo DB_VERSION; ?>;
    </script>
    <?php
    echo $widget->google_alaytics();
    echo $widget->GTM_head();
    ?>
</head>

<body class="bootstrap<?php echo $isDarkMode ? '-dark' : ' bg-light'; ?> mb-5">
    <?php
    echo $widget->GTM_body();
    ?>
    <a class="sr-only sr-only-focusable" href="#main">Skip to main content</a>
    <div class="container-xl rounded-bottom <?php echo $isDarkMode ? 'bg-dark' : 'bg-white'; ?> shadow">
        <header id="header">
            <nav class="navbar navbar-expand-lg container-xl fixed-top shadow bg-custom navbar-dark">
                <a class="navbar-brand" href=""><?php echo get_env('site_name'); ?></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse navbar-nav-scroll" id="navbarCollapse" style="max-height:calc(100vh - 56px)">
                    <ul class="navbar-nav ml-auto">
                        <?php
                        echo $widget->createMenu('Home', BASE_URL, '', 'fas fa-home mr-2');
                        if ($isAdmin || (is_anonymous() && validate_boolean(get_option('enable_gsharer')))) {
                            session_write_close();
                            echo $widget->createMenu('Bypass Limit', BASE_URL . 'sharer/', '', 'fab fa-google-drive mr-2');
                        }
                        if ($userLogin) {
                            session_write_close();
                            echo $widget->createMenu('User Panel', ADMIN_URL . '/dashboard/', '', 'fas fa-user-circle mr-2', array(
                                $widget->createSubMenu('Dashboard', ADMIN_URL . '/dashboard/', '', 'fas fa-tachometer-alt mr-2'),
                                $widget->createSubMenu('My Videos', ADMIN_URL . '/videos/list/', '', 'fas fa-film mr-2'),
                                $widget->createSubMenu('My Account', ADMIN_URL . '/profile/', '', 'fas fa-user mr-2'),
                                $widget->createSubMenuDivider(),
                                $widget->createSubMenu('Logout', ADMIN_URL . '/login/?logout=true', '', 'fas fa-sign-out-alt mr-2'),
                            ));
                        } elseif (is_anonymous()) {
                            session_write_close();
                            echo $widget->createMenu('Login', ADMIN_URL . '/login/', '', 'fas fa-sign-in-alt mr-2');
                            if (!file_exists(BASE_DIR . '.rent') && validate_boolean(get_option('enable_registration'))) {
                                session_write_close();
                                echo $widget->createMenu('Register', ADMIN_URL . '/register/', '', 'fas fa-user-plus mr-2');
                            }
                        }
                        echo $widget->createMenu('Theme Mode', '#', '', 'fas fa-' . ($isDarkMode ? 'moon' : 'sun') . ' ico-theme mr-2', array(
                            $widget->createSubMenu('Light', $_SERVER['REQUEST_URI'] . '#theme=light', '', 'fas fa-sun mr-2'),
                            $widget->createSubMenu('Dark', $_SERVER['REQUEST_URI'] . '#theme=dark', '', 'fas fa-moon mr-2')
                        ));
                        $dev = parse_url(BASE_URL, PHP_URL_HOST);
                        if (strpos($dev, 'gdplayer.') !== false || strpos($dev, 'localhost') !== false) {
                            session_write_close();
                            echo $widget->createMenu('Live TV', 'https://gdplayertv.top/', '', 'fas fa-tv mr-2');
                            echo $widget->createMenu('Buy', BASE_URL . 'buy/', '', 'fas fa-shopping-basket mr-2', array(
                                $widget->createSubMenu('Buy Video Player', BASE_URL . 'buy/', '', 'fas fa-shopping-basket mr-2'),
                                $widget->createSubMenu('Buy Additional Hosts', BASE_URL . 'buy-additional-host/', '', 'fas fa-plus-circle mr-2')
                            ), 'btn btn-block btn-green', 'dropdown-menu-right');
                        }
                        ?>
                    </ul>
                </div>
            </nav>
        </header>
        <main id="main" class="pb-5" style="margin-top:56px">