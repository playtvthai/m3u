<?php
session_write_close();

$ex = array_pad(explode('/', trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/')), 2, '');
$url = 'https://media.cm/' . end($ex);

$sec = new \GDPlayer\Security();
redirectTo(BASE_URL . 'e/?' . $sec->encryptURL('id=' . $url));
exit;

function saveMediaCustomSlug(string $slug = '')
{
    session_write_close();
    global $video, $id, $host, $poster, $title;
    if (!empty($slug)) {
        session_write_close();
        $short = new \GDPlayer\Model\VideoShort();
        $short->setCriteria('key', $slug);
        if ($short->getNumRows() === 0) {
            session_write_close();
            $time = time();
            $vid = $video->insert([
                'host' => $host,
                'host_id' => $id,
                'title' => $title,
                'uid' => 1,
                'added' => $time,
                'updated' => $time,
                'poster' => $poster
            ]);
            if ($vid) {
                session_write_close();
                $short->insert([
                    'key' => $slug,
                    'vid' => $vid
                ]);
                redirectTo(BASE_URL . 'e/' . $slug);
            } else {
                session_write_close();
                saveMediaCustomSlug(create_slug(random_string('20')));
            }
        } else {
            session_write_close();
            saveMediaCustomSlug(create_slug(random_string('20')));
        }
    } else {
        session_write_close();
        saveMediaCustomSlug(create_slug(random_string('20')));
    }
}

$hosting = new \GDPlayer\Hosting($url);
$host = $hosting->getHost();
$id = $hosting->getID();

$video = new \GDPlayer\Model\Video();
$video->setCriteria('host', $host);
$video->setCriteria('host_id', $id, '=', 'AND');
$data = $video->getOne(['id']);
if ($data) {
    session_write_close();
    $short = new \GDPlayer\Model\VideoShort();
    $short->setCriteria('vid', $data['id']);
    $dataShort = $short->getOne(['key']);
    if ($dataShort) {
        session_write_close();
        redirectTo(BASE_URL . 'e/' . $dataShort['key']);
        exit();
    }
}
$media = new \GDPlayer\Hosting\mediacm($id, false, 'mediacm');
$media->getSources();
$poster = $media->getImage();
$title = $media->getTitle();
$slug = '';
if (!empty($title)) {
    session_write_close();
    $slug = create_slug($title);
} else {
    session_write_close();
    $slug = create_slug($hostId);
}
saveMediaCustomSlug($slug);
