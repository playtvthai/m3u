<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}

if (!validate_boolean(get_option('enable_gsharer')) && !is_admin()) {
    session_write_close();
    include_once BASE_DIR . 'includes/views/403.php';
    exit();
}

$topBanner = get_option('sh_banner_top');
$bottomBanner = get_option('sh_banner_bottom');

$html = new \GDPlayer\HTML();
set_env('title', 'Google Drive Direct Link Generator & Downloader');
set_env('description', 'Generate direct links and download Google Drive files without signing in to a Google account.');
get_frontend_header();
?>
<div class="row bg-custom text-center">
    <div class="col py-5">
        <h1 class="h3">Google Drive Direct Link Generator &amp; Downloader</h1>
        <p>Generate direct link and download Google Drive file without signing in to a Google account.</p>
    </div>
</div>
<?php echo loadAds('mt-5'); ?>
<div class="row mt-3">
    <?php
    if (!empty($topBanner)) {
        session_write_close();
        echo '<div class="col-12 mb-3">' . $topBanner . '</div>';
    }
    ?>
    <div class="col-12">
        <?php
        echo $html->renderTemplate('gdrive/sharer.html.twig', [
            'recaptcha_site_key' => get_option('recaptcha_site_key'),
            'enable_ajax_downloader' => validate_boolean(get_option('enable_gdrive_downloader')),
            'baseURL' => BASE_URL,
        ]);
        ?>
    </div>
    <?php
    if (!empty($bottomBanner)) {
        session_write_close();
        echo '<div class="col-12 mt-3">' . $bottomBanner . '</div>';
    }
    ?>
</div>
<?php
get_frontend_footer();
