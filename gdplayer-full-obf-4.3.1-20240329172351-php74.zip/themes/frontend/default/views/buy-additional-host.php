<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}

set_env('title', 'Buy GDPlayer Google Drive Video Player');
set_env('description', 'Buy GDPlayer Google Drive Video Player Full Version only on the official site. Get lifetime update support.');
get_frontend_header();
?>
<div class="row pt-5">
    <div class="col-sm-6 col-lg-3 mb-3">
        <div class="card shadow-sm">
            <div class="card-header p-2 text-center">
                <h2 class="h5">Buy Single Host</h2>
                <h4 class="card-subtitle h5 mb-0 text-primary">$10</h4>
            </div>
            <div class="card-body p-2 text-center">
                <a rel="noopener" href="https://bit.ly/single-host" target="_blank" class="btn btn-block btn-primary">Buy Now</a>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-lg-3 mb-3">
        <div class="card shadow-sm">
            <div class="card-header p-2 text-center">
                <h2 class="h5">Buy Additional Hosts</h2>
                <h4 class="card-subtitle h5 mb-0 text-primary">$50</h4>
            </div>
            <div class="card-body p-2 text-center">
                <a rel="noopener" href="https://bit.ly/additional-hosts" target="_blank" class="btn btn-block btn-danger">Buy Now</a>
            </div>
        </div>
    </div>
</div>
<?php
echo loadAds();
get_frontend_footer();
