<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}
$plugins = new \GDPlayer\Plugins();
$widget = new \GDPlayer\Widget();
$opt = extractOptions(['pwa_themecolor', 'custom_color', 'custom_color2']);
$themeColor = '#' . ($opt['pwa_themecolor'] ?: '673ab7');
$rgbColor = hex2RGB(trim($themeColor, '#'), true, ',') ?: '103, 58, 183';
$customColor = '#' . ($opt['custom_color'] ?: '673ab7');
$customColor2 = '#' . ($opt['custom_color2'] ?: '#3f51b5');
$themePath = 'themes/backend/default/assets';

echo $widget->loadCdnJsStyle('font-awesome/6.4.2/css/all.min.css');
echo $widget->loadCdnJsStyle('bootstrap/4.6.2/css/bootstrap.min.css');
echo $widget->loadCdnJsStyle('bootstrap-sweetalert/1.0.1/sweetalert.min.css');
echo $widget->loadCdnJsStyle('select2/4.0.13/css/select2.min.css');
echo $widget->loadStyle('assets/vendor/select2-bootstrap4-theme/select2-bootstrap4.min.css');
echo $widget->loadStyle('assets/vendor/jquery-wheelcolorpicker/css/wheelcolorpicker.min.css');
echo $widget->loadCdnJsStyle('toastify-js/1.12.0/toastify.min.css');
echo $widget->loadCdnJsStyle('apexcharts/3.41.1/apexcharts.min.css');
echo $widget->loadCdnJsStyle('multi-select/0.9.12/css/multi-select.min.css');
echo $widget->loadStyle(
    '//cdn.datatables.net/v/bs4/dt-1.13.2/fc-4.2.1/fh-3.3.1/r-2.4.0/rg-1.3.0/sr-1.2.1/datatables.min.css'
);
echo $widget->loadStyle("assets/css/bs-dark-v1.3.css");
echo $widget->loadStyle("$themePath/css/style-v3.3.min.css");
?>
<style>
    a,
    .page-link,
    .btn-outline-custom {
        color: <?php echo $customColor; ?>;
    }

    .btn-outline-custom {
        border-color: <?php echo $customColor; ?>;
    }

    a:hover,
    .page-link:hover {
        color: <?php echo $customColor2; ?>;
    }

    .border-custom {
        border-color: <?php echo $customColor; ?> !important;
    }

    div.dataTables_processing>div:last-child>div,
    .select2-container--bootstrap4 .select2-results__option--highlighted,
    .select2-container--bootstrap4 .select2-results__option--highlighted.select2-results__option[aria-selected=true],
    .page-item.active .page-link,
    .dropdown-item.active,
    .dropdown-item:active,
    .bg-custom,
    .btn-custom,
    .nav-pills .nav-link.active,
    .nav-pills .show>.nav-link {
        color: #fff;
        border-color: <?php echo $customColor; ?>;
        background-color: <?php echo $customColor; ?>;
        background-image: -webkit-linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
        background-image: -moz-linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
        background-image: -o-linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>);
        background-image: linear-gradient(to right, <?php echo $customColor; ?>, <?php echo $customColor2; ?>)
    }

    .btn-outline-custom.active,
    .btn-outline-custom:active,
    .btn-outline-custom.focus,
    .btn-outline-custom:focus,
    .btn-outline-custom:not(:disabled):hover,
    .btn-custom.focus,
    .btn-custom:focus,
    .btn-custom:not(:disabled):hover {
        color: #fff !important;
        border-color: <?php echo $customColor2; ?>;
        background-image: -webkit-linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-image: -moz-linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-image: -o-linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-image: linear-gradient(to right, <?php echo $customColor2; ?>, <?php echo $customColor; ?>);
        background-color: <?php echo $customColor2; ?>;
    }

    .page-link:focus,
    .btn-outline-custom.focus,
    .btn-outline-custom:focus,
    .btn-outline-custom:not(:disabled):hover,
    .btn-custom.focus,
    .btn-custom:focus {
        box-shadow: 0 0 0 .2rem rgba(<?php echo $rgbColor; ?>, .2) !important
    }

    .table-hover tbody tr:hover td {
        background-color: rgba(<?php echo $rgbColor; ?>, .07) !important;
    }

    .bootstrap-dark .table-hover tbody tr:hover td {
        background-color: rgba(<?php echo $rgbColor; ?>, .2) !important;
    }

    #subsWrapper .input-group-prepend {
        max-width: 150px;
    }

    #footer .nav-link.active,
    #footer .nav-link:active,
    #footer .nav-link:focus,
    #footer .nav-link:hover {
        color: <?php echo $customColor; ?> !important;
    }
</style>
<?php
$cssLinks = $plugins->getBackendCSS(true);
if ($cssLinks) {
    session_write_close();
    echo $cssLinks;
}
