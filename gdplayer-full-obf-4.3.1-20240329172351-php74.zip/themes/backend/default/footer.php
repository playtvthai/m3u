<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}
$hosting = new \GDPlayer\Hosting();
$plugins = new \GDPlayer\Plugins();
$widget = new \GDPlayer\Widget();
$userLogin = current_user();
$isAdmin = $userLogin && intval($userLogin['role']) === 0;
$opt = extractOptions(['dmca_page_link', 'contact_page_link', 'pwa_themecolor', 'custom_color', 'custom_color2']);
$dmca_link = $opt['dmca_page_link'];
$contact_link = $opt['contact_page_link'];
$themeColor = $opt['pwa_themecolor'];
$themeColor = !empty($themeColor) ? '#' . $themeColor : '#673ab7';
$rgbColor = hex2RGB(trim($themeColor, '#'), true, ',');
$rgbColor = $rgbColor ? $rgbColor : '103, 58, 183';
$customColor = !empty($opt['custom_color']) ? '#' . $opt['custom_color'] : '#673ab7';
$customColor2 = !empty($opt['custom_color2']) ? '#' . $opt['custom_color2'] : '#3f51b5';
?>
</main>
<footer id="footer" class="row py-5 bg-dark text-center text-light rounded-bottom">
    <div class="col-12">
        <ul class="nav justify-content-center mb-3">
            <li class="nav-item">
                <a class="nav-link" href="">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="changelog/">Change Log</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="terms/">Terms</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="privacy/">Privacy</a>
            </li>
            <?php if (!empty($dmca_link)) : ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo $dmca_link; ?>" target="_blank" rel="noopener">DMCA</a>
                </li>
            <?php endif; ?>
            <?php if (!empty($contact_link)) : ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo $contact_link; ?>" target="_blank" rel="noopener">Contact</a>
                </li>
            <?php endif; ?>
        </ul>
        <p>&copy; 2020 - <?php echo date('Y'); ?>. Made with <em class="fas fa-heart text-danger"></em> by <?php echo sitename(); ?>.</p>
    </div>
</footer>
</div>
<button type="button" id="gotoTop" title="Go to Top" class="bg-custom shadow">
    <span class="gotoContent">
        <em class="fas fa-chevron-up"></em>
    </span>
</button>
<?php
include_once BACKEND_THEME_PATH . DIRECTORY_SEPARATOR . 'scripts.php';
?>
</body>

</html>
<?php
$output = ob_get_contents();
ob_end_clean();
$output = gzencode($output, 9);
header('Content-Encoding: gzip');
header('Content-Length: ' . strlen($output));
echo $output;
